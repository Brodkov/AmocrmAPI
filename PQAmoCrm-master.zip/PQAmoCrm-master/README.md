# Коннектор Power Query/Power BI для AmoCRM
Для запуска требуется только один файл — PQAmoCRM.m
Содержимое файла копируем в расширенный редактор, заполняем необходимые данные.

Доступные поля для method:
- Leads → выгрузка сделок
- Contacts → выгрузка контактов
- Notes → выгрузка примечаний
- Tasks → выгрузка задач.

[Blog](zabitov.ru)
[Facebook](https://www.facebook.com/eldar.zabitov.5)
